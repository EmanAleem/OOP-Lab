/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dishes;

/**
 *
 * @author MARK 1
 */
import java.util.Scanner;

public class Dishes {
    private String type;
    private String ingredients;
    private String cuisine;

    // Method to get dish details from the user
    public void getDetails() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the type of dish (e.g., sweets, savory, etc.): ");
        type = scanner.nextLine();

        System.out.print("Enter the ingredients used: ");
        ingredients = scanner.nextLine();

        System.out.print("Enter the cuisine (e.g., Asian, Italian, etc.): ");
        cuisine = scanner.nextLine();
    }

    // Method to display dish details
    public void displayDetails() {
        System.out.println("Welcome to the Asian Restaurant");
        System.out.println("Your selected choice of Dish is " + type);
        System.out.println("Your Dish contains the following ingredients: " + ingredients);
        System.out.println("Your dish belongs to the " + cuisine + " cuisine");
    }

    // Main method to run the program
    public static void main(String[] args) {
        Dishes dish = new Dishes(); // Create an object of Dishes
        dish.getDetails(); // Get dish details from the user
        dish.displayDetails(); // Display the dish details
    }
}
