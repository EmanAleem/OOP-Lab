/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hauntedhousegame;

/**
 *
 * @author MARK 1
 */
import java.util.Scanner;

public class HauntedHouseGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] mysteryWords = {"GHOST", "VAMPIRE", "ZOMBIE"};

        System.out.println("Welcome to the Haunted House!");
        System.out.println("Solve the mystery words to escape...\n");
        
        for (int i = 0; i < mysteryWords.length; i++) {
            String word = mysteryWords[i];
            char hint = word.charAt(0); // First letter as a hint
            String guess;

            System.out.println("You are in Room " + (i + 1) + ".");
            System.out.println("Hint: The word starts with '" + hint + "'.");

            do {
                System.out.print("Enter your guess: ");
                guess = scanner.nextLine().toUpperCase();
                
                if (!guess.equals(word)) {
                    System.out.println("Wrong guess! Try again.");
                }
            } while (!guess.equals(word));

            System.out.println("Correct! You move to the next room.\n");
        }

        System.out.println("Congratulations! You escaped the Haunted House!");
        scanner.close();
    }
}

