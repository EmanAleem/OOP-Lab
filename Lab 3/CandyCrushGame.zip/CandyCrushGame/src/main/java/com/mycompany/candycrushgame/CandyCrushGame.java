/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.candycrushgame;

/**
 *
 * @author MARK 1
 */
public class CandyCrushGame {
    
    private String playerName;
    private int score;
    private int level;
   
    public CandyCrushGame(String playerName) {
        this.playerName = playerName;
        this.score = 0;
        this.level = 1;
    }
    
    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
    
    public void performAction(int action) {
        switch (action) {
            case 1:
                System.out.println(playerName + " matched candies! +10 points");
                score += 10;
                break;
            case 2:
                System.out.println(playerName + " cleared a row! +20 points");
                score += 20;
                break;
            case 3:
                System.out.println(playerName + " completed a level!");
                level++;
                break;
            default:
                System.out.println("Invalid action! Try again.");
        }
    }
    
    public void displayStatus() {
        System.out.println("Player: " + playerName + ", Score: " + score + ", Level: " + level);
    }
    
    public static void main(String[] args) {
        CandyCrushGame game = new CandyCrushGame("Alice");
        game.performAction(1);
        game.displayStatus();
        game.performAction(2);
        game.displayStatus();
        game.performAction(3);
        game.displayStatus();
    }
}