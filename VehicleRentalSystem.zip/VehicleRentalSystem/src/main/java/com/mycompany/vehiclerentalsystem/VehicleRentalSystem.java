/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Eman,Aimen,Arfa
 */


import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VehicleRentalSystem extends JFrame {

    class Vehicle {
        String id, model, type;
        boolean isRented;

        Vehicle(String id, String model, String type) {
            this.id = id;
            this.model = model;
            this.type = type;
            this.isRented = false;
        }
    }

    private ArrayList<Vehicle> vehicles = new ArrayList<>();
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);

    // Panels
    private JPanel welcomePanel, loginPanel, menuPanel, addVehiclePanel, rentVehiclePanel, returnVehiclePanel, viewVehiclePanel;
    
    // Welcome components
    private JButton proceedLoginBtn;
    
    // Login components
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginBtn;
    
    // Menu components
    private JButton addVehicleBtn, rentVehicleBtn, returnVehicleBtn, viewVehiclesBtn, logoutBtn;
    
    // Add Vehicle components
    private JTextField addIdField, addModelField, addTypeField;
    private JButton addSubmitBtn, updateBtn, addBackBtn;
    
    // Rent Vehicle components
    private JTextField rentIdField;
    private JButton rentSubmitBtn, rentBackBtn;
    
    // Return Vehicle components
    private JTextField returnIdField;
    private JButton returnSubmitBtn, returnBackBtn;
    
    // View Vehicles components
    private JTable vehicleTable;
    private DefaultTableModel vehicleTableModel;
    private JTextField searchField;
    private JButton searchBtn, refreshBtn, viewBackBtn, deleteBtn;

    public VehicleRentalSystem() {
        initializeUI();
        setupPanels();
        setVisible(true);
    }

    private void initializeUI() {
        setTitle("Vehicle Rental Management System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        createWelcomePanel();
        createLoginPanel();
        createMenuPanel();
        createAddVehiclePanel();
        createRentVehiclePanel();
        createReturnVehiclePanel();
        createViewVehiclePanel();
    }

    private void setupPanels() {
        mainPanel.add(welcomePanel, "Welcome");
        mainPanel.add(loginPanel, "Login");
        mainPanel.add(menuPanel, "Menu");
        mainPanel.add(addVehiclePanel, "AddVehicle");
        mainPanel.add(rentVehiclePanel, "RentVehicle");
        mainPanel.add(returnVehiclePanel, "ReturnVehicle");
        mainPanel.add(viewVehiclePanel, "ViewVehicles");
        
        add(mainPanel);
        cardLayout.show(mainPanel, "Welcome");
    }

    private void createWelcomePanel() {
        welcomePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_logo.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    g.setColor(new Color(245, 245, 220));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        welcomePanel.setOpaque(false);

        JPanel overlayPanel = new JPanel();
        overlayPanel.setLayout(new BoxLayout(overlayPanel, BoxLayout.Y_AXIS));
        overlayPanel.setOpaque(false);
        overlayPanel.setBorder(new EmptyBorder(150, 50, 150, 50));

        JLabel welcomeLabel = new JLabel("Welcome to Vehicle Rental System", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 32));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        welcomeLabel.setOpaque(true);
        welcomeLabel.setBackground(new Color(0, 0, 0, 120));
        welcomeLabel.setBorder(new EmptyBorder(15, 20, 15, 20));

        overlayPanel.add(welcomeLabel);
        overlayPanel.add(Box.createVerticalStrut(40));

        proceedLoginBtn = new JButton("Proceed to Login");
        proceedLoginBtn.setBackground(new Color(255, 165, 0));
        proceedLoginBtn.setForeground(Color.BLACK);
        proceedLoginBtn.setFont(new Font("Segoe UI", Font.BOLD, 20));
        proceedLoginBtn.setFocusPainted(false);
        proceedLoginBtn.setBorder(BorderFactory.createRaisedBevelBorder());
        proceedLoginBtn.setPreferredSize(new Dimension(220, 50));
        proceedLoginBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        proceedLoginBtn.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false);
        buttonPanel.add(proceedLoginBtn);
        overlayPanel.add(buttonPanel);

        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setOpaque(false);
        centerWrapper.add(overlayPanel);

        welcomePanel.add(centerWrapper, BorderLayout.CENTER);
    }

    private void createLoginPanel() {
        loginPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_login 2.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                }
            }
        };
        loginPanel.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(245, 245, 220, 200));
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        JLabel titleLabel = new JLabel("LOGIN", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        titleLabel.setForeground(new Color(54, 69, 79));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 30, 0));

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        usernameField.setPreferredSize(new Dimension(250, 35));
        
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        passwordField.setPreferredSize(new Dimension(250, 35));
        
        loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(54, 69, 79));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        loginBtn.setFocusPainted(false);
        loginBtn.setPreferredSize(new Dimension(200, 45));

        loginBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            if ("admin".equals(username) && "admin123".equals(password)) {
                usernameField.setText("");
                passwordField.setText("");
                cardLayout.show(mainPanel, "Menu");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        formPanel.add(userLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        formPanel.add(usernameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        formPanel.add(passLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        formPanel.add(passwordField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(loginBtn, gbc);
        
        loginPanel.add(formPanel);
    }

    private void createMenuPanel() {
        menuPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_login.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                }
            }
        };
        menuPanel.setOpaque(false);
        
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 15, 15));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 100, 50, 100));
        buttonPanel.setBackground(new Color(224, 255, 255, 180));
        buttonPanel.setOpaque(false);

        addVehicleBtn = createMenuButton("Add Vehicle");
        rentVehicleBtn = createMenuButton("Rent Vehicle");
        returnVehicleBtn = createMenuButton("Return Vehicle");
        viewVehiclesBtn = createMenuButton("View Vehicles");
        logoutBtn = createMenuButton("Logout");

        addVehicleBtn.addActionListener(e -> {
            clearAddVehicleFields();
            cardLayout.show(mainPanel, "AddVehicle");
        });
        rentVehicleBtn.addActionListener(e -> cardLayout.show(mainPanel, "RentVehicle"));
        returnVehicleBtn.addActionListener(e -> cardLayout.show(mainPanel, "ReturnVehicle"));
        viewVehiclesBtn.addActionListener(e -> {
            refreshVehicleTable();
            cardLayout.show(mainPanel, "ViewVehicles");
        });
        logoutBtn.addActionListener(e -> cardLayout.show(mainPanel, "Login"));

        buttonPanel.add(addVehicleBtn);
        buttonPanel.add(rentVehicleBtn);
        buttonPanel.add(returnVehicleBtn);
        buttonPanel.add(viewVehiclesBtn);
        buttonPanel.add(logoutBtn);
        
        menuPanel.add(buttonPanel, BorderLayout.CENTER);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(65, 105, 225, 220)); 
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 18));
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(250, 60));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
        return btn;
    }

    private void createAddVehiclePanel() {
        addVehiclePanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_addvehicle.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                    g.setColor(new Color(230, 230, 250));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        addVehiclePanel.setOpaque(false);
        
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(255, 255, 255, 200));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(65, 105, 225, 200), 2),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Add/Update Vehicle", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(50, 50, 50));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        JLabel addIdLabel = new JLabel("Vehicle ID:");
        addIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JLabel addModelLabel = new JLabel("Model:");
        addModelLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JLabel addTypeLabel = new JLabel("Type:");
        addTypeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        addIdField = new JTextField(15);
        addIdField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addModelField = new JTextField(15);
        addModelField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        addTypeField = new JTextField(15);
        addTypeField.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        addSubmitBtn = new JButton("Add Vehicle");
        updateBtn = new JButton("Update Vehicle");
        addBackBtn = new JButton("Back to Menu");

        styleButton(addSubmitBtn, new Color(65, 105, 225, 220));
        styleButton(updateBtn, new Color(75, 150, 75, 220));
        styleButton(addBackBtn, new Color(100, 100, 100, 220));

        addSubmitBtn.addActionListener(e -> addVehicle());
        updateBtn.addActionListener(e -> updateVehicle());
        addBackBtn.addActionListener(e -> {
            clearAddVehicleFields();
            cardLayout.show(mainPanel, "Menu");
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        formPanel.add(addIdLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        formPanel.add(addIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        formPanel.add(addModelLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        formPanel.add(addModelField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.LINE_END;
        formPanel.add(addTypeLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        formPanel.add(addTypeField, gbc);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        buttonPanel.setOpaque(false);
        buttonPanel.add(addSubmitBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(addBackBtn);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(buttonPanel, gbc);
        
        addVehiclePanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));
        addVehiclePanel.add(formPanel);
    }

    private void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createRaisedBevelBorder(),
            BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

    private void createRentVehiclePanel() {
        rentVehiclePanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_rent.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                    Graphics2D g2d = (Graphics2D)g;
                    Paint oldPaint = g2d.getPaint();
                    
                    Color baseColor = new Color(245, 255, 250);
                    Color stripeColor = new Color(235, 245, 240);
                    
                    g2d.setPaint(baseColor);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                    
                    g2d.setPaint(new GradientPaint(0, 0, stripeColor, 15, 15, baseColor, true));
                    for (int x = -getHeight(); x < getWidth(); x += 6) {
                        g2d.drawLine(x, 0, x + getHeight(), getHeight());
                    }
                    g2d.setPaint(oldPaint);
                }
            }
        };
        rentVehiclePanel.setOpaque(false);
        rentVehiclePanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(255, 255, 255, 200));
        contentPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 150, 0, 200), 2),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titleLabel = new JLabel("Rent Vehicle", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 100, 0));
        
        JLabel rentIdLabel = new JLabel("Vehicle ID to Rent:");
        rentIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        
        rentIdField = new JTextField(20);
        rentIdField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        
        rentSubmitBtn = new JButton("Rent Vehicle");
        rentBackBtn = new JButton("Back to Menu");
        
        styleButton(rentSubmitBtn, new Color(0, 150, 0, 220));
        styleButton(rentBackBtn, new Color(100, 100, 100, 220));

        rentSubmitBtn.addActionListener(e -> rentVehicle());
        rentBackBtn.addActionListener(e -> {
            rentIdField.setText("");
            cardLayout.show(mainPanel, "Menu");
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        contentPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        contentPanel.add(rentIdLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        contentPanel.add(rentIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        contentPanel.add(rentSubmitBtn, gbc);

        gbc.gridx = 1;
        contentPanel.add(rentBackBtn, gbc);
        
        rentVehiclePanel.add(contentPanel);
    }

    private void createReturnVehiclePanel() {
        returnVehiclePanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_return.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                    Graphics2D g2d = (Graphics2D)g;
                    Paint oldPaint = g2d.getPaint();
                    
                    Color baseColor = new Color(255, 240, 245);
                    Color dotColor = new Color(245, 230, 235);
                    
                    g2d.setPaint(baseColor);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                    
                    g2d.setPaint(dotColor);
                    for (int x = 0; x < getWidth(); x += 8) {
                        for (int y = 0; y < getHeight(); y += 8) {
                            if ((x + y) % 16 == 0) {
                                g2d.fillOval(x, y, 2, 2);
                            }
                        }
                    }
                    g2d.setPaint(oldPaint);
                }
            }
        };
        returnVehiclePanel.setOpaque(false);
        returnVehiclePanel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));
        
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(255, 255, 255, 200));
        contentPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 0, 0, 200), 2),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.anchor = GridBagConstraints.CENTER;

        JLabel titleLabel = new JLabel("Return Vehicle", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(new Color(150, 0, 0));
        
        JLabel returnIdLabel = new JLabel("Vehicle ID to Return:");
        returnIdLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        
        returnIdField = new JTextField(20);
        returnIdField.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        
        returnSubmitBtn = new JButton("Return Vehicle");
        returnBackBtn = new JButton("Back to Menu");
        
        styleButton(returnSubmitBtn, new Color(200, 0, 0, 220));
        styleButton(returnBackBtn, new Color(100, 100, 100, 220));

        returnSubmitBtn.addActionListener(e -> returnVehicle());
        returnBackBtn.addActionListener(e -> {
            returnIdField.setText("");
            cardLayout.show(mainPanel, "Menu");
        });

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        contentPanel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        contentPanel.add(returnIdLabel, gbc);
        
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        contentPanel.add(returnIdField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.CENTER;
        contentPanel.add(returnSubmitBtn, gbc);

        gbc.gridx = 1;
        contentPanel.add(returnBackBtn, gbc);
        
        returnVehiclePanel.add(contentPanel);
    }

    private void createViewVehiclePanel() {
        viewVehiclePanel = new JPanel(new BorderLayout(10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    ImageIcon originalIcon = new ImageIcon(getClass().getResource("/car_viewvehicle.png"));
                    Image image = originalIcon.getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.out.println("Background image not found");
                    Graphics2D g2d = (Graphics2D)g;
                    Paint oldPaint = g2d.getPaint();
                    
                    Color baseColor = new Color(255, 255, 224);
                    Color lineColor = new Color(245, 245, 214);
                    
                    g2d.setPaint(baseColor);
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                    
                    g2d.setPaint(lineColor);
                    for (int x = 0; x < getWidth(); x += 20) {
                        g2d.drawLine(x, 0, x, getHeight());
                    }
                    for (int y = 0; y < getHeight(); y += 20) {
                        g2d.drawLine(0, y, getWidth(), y);
                    }
                    g2d.setPaint(oldPaint);
                }
            }
        };
        viewVehiclePanel.setOpaque(false);
        viewVehiclePanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(255, 255, 255, 200));
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180, 200), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        vehicleTableModel = new DefaultTableModel(new Object[]{"ID", "Model", "Type", "Status"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        vehicleTable = new JTable(vehicleTableModel);
        vehicleTable.setFillsViewportHeight(true);
        vehicleTable.setBackground(new Color(255, 255, 255));
        vehicleTable.setSelectionBackground(new Color(70, 130, 180, 150));
        vehicleTable.setSelectionForeground(Color.WHITE);
        vehicleTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        vehicleTable.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        vehicleTable.setRowHeight(25);
        
        vehicleTable.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) {
                    int row = vehicleTable.getSelectedRow();
                    if (row >= 0) {
                        String id = (String) vehicleTableModel.getValueAt(row, 0);
                        String model = (String) vehicleTableModel.getValueAt(row, 1);
                        String type = (String) vehicleTableModel.getValueAt(row, 2);
                        
                        addIdField.setText(id);
                        addModelField.setText(model);
                        addTypeField.setText(type);
                        
                        cardLayout.show(mainPanel, "AddVehicle");
                    }
                }
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(vehicleTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        searchPanel.setBackground(new Color(255, 255, 255, 200));
        searchPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        searchField = new JTextField(20);
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(150, 150, 150)),
            BorderFactory.createEmptyBorder(5, 8, 5, 8)
        ));
        
        searchBtn = new JButton("Search");
        refreshBtn = new JButton("Refresh");
        
        styleButton(searchBtn, new Color(70, 130, 180, 220));
        styleButton(refreshBtn, new Color(70, 130, 180, 220));

        searchBtn.addActionListener(e -> searchVehicles());
        refreshBtn.addActionListener(e -> refreshVehicleTable());

        searchPanel.add(new JLabel("Search by Model or Type:"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        searchPanel.add(refreshBtn);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(new Color(255, 255, 255, 200));
        buttonPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        deleteBtn = new JButton("Delete Vehicle");
        styleButton(deleteBtn, new Color(220, 20, 60, 220)); // Red color for delete
        deleteBtn.addActionListener(e -> deleteVehicle());
        
        viewBackBtn = new JButton("Back to Menu");
        styleButton(viewBackBtn, new Color(100, 100, 100, 220));
        viewBackBtn.addActionListener(e -> cardLayout.show(mainPanel, "Menu"));
        
        buttonPanel.add(deleteBtn);
        buttonPanel.add(viewBackBtn);

        viewVehiclePanel.add(searchPanel, BorderLayout.NORTH);
        viewVehiclePanel.add(tablePanel, BorderLayout.CENTER);
        viewVehiclePanel.add(buttonPanel, BorderLayout.SOUTH);
    }

    private void addVehicle() {
        String id = addIdField.getText().trim();
        String model = addModelField.getText().trim();
        String type = addTypeField.getText().trim();

        if (id.isEmpty() || model.isEmpty() || type.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Vehicle v : vehicles) {
            if (v.id.equals(id)) {
                JOptionPane.showMessageDialog(this, "Vehicle ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        vehicles.add(new Vehicle(id, model, type));
        JOptionPane.showMessageDialog(this, "Vehicle added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        clearAddVehicleFields();
    }

    private void updateVehicle() {
        String id = addIdField.getText().trim();
        String model = addModelField.getText().trim();
        String type = addTypeField.getText().trim();

        if (id.isEmpty() || model.isEmpty() || type.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Vehicle v : vehicles) {
            if (v.id.equals(id)) {
                v.model = model;
                v.type = type;
                JOptionPane.showMessageDialog(this, "Vehicle updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearAddVehicleFields();
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Vehicle ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void rentVehicle() {
        String id = rentIdField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Vehicle ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Vehicle v : vehicles) {
            if (v.id.equals(id)) {
                if (v.isRented) {
                    JOptionPane.showMessageDialog(this, "Vehicle already rented.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    v.isRented = true;
                    JOptionPane.showMessageDialog(this, "Vehicle rented successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
                rentIdField.setText("");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Vehicle ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void returnVehicle() {
        String id = returnIdField.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Vehicle ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (Vehicle v : vehicles) {
            if (v.id.equals(id)) {
                if (!v.isRented) {
                    JOptionPane.showMessageDialog(this, "Vehicle was not rented.", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    v.isRented = false;
                    JOptionPane.showMessageDialog(this, "Vehicle returned successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
                returnIdField.setText("");
                return;
            }
        }

        JOptionPane.showMessageDialog(this, "Vehicle ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void refreshVehicleTable() {
        vehicleTableModel.setRowCount(0);
        for (Vehicle v : vehicles) {
            vehicleTableModel.addRow(new Object[]{
                    v.id,
                    v.model,
                    v.type,
                    v.isRented ? "Rented" : "Available"
            });
        }
    }

    private void searchVehicles() {
        String keyword = searchField.getText().trim().toLowerCase();
        vehicleTableModel.setRowCount(0);
        for (Vehicle v : vehicles) {
            if (v.model.toLowerCase().contains(keyword) || v.type.toLowerCase().contains(keyword)) {
                vehicleTableModel.addRow(new Object[]{
                        v.id,
                        v.model,
                        v.type,
                        v.isRented ? "Rented" : "Available"
                });
            }
        }
    }

    private void deleteVehicle() {
        int selectedRow = vehicleTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a vehicle to delete", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String vehicleId = (String) vehicleTableModel.getValueAt(selectedRow, 0);
        
        int confirm = JOptionPane.showConfirmDialog(
            this, 
            "Are you sure you want to delete vehicle " + vehicleId + "?", 
            "Confirm Deletion", 
            JOptionPane.YES_NO_OPTION
        );
        
        if (confirm == JOptionPane.YES_OPTION) {
            // Remove from vehicles list
            vehicles.removeIf(v -> v.id.equals(vehicleId));
            
            // Remove from table model
            vehicleTableModel.removeRow(selectedRow);
            
            JOptionPane.showMessageDialog(this, "Vehicle deleted successfully", "Success", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void clearAddVehicleFields() {
        addIdField.setText("");
        addModelField.setText("");
        addTypeField.setText("");
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            new VehicleRentalSystem();
        });
    }
}