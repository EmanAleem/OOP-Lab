/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.volumecalculation;

/**
 *
 * @author MARK 1
 */
public class Cylinder extends Shape3D {
    double radius, height;
    Cylinder(double radius, double height) {
        this.radius = radius;
        this.height = height;
    }
    double calculateBaseArea() {
        return Math.PI * radius * radius;  
    }
}

// Grandchild Class (Inheriting Cylinder)
