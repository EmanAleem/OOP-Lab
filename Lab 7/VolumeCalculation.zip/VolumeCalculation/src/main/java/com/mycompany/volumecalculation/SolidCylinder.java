/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.volumecalculation;

/**
 *
 * @author MARK 1
 */
public class SolidCylinder extends Cylinder {
    // Constructor
    SolidCylinder(double radius, double height) {
        super(radius, height);
    }

    // Method to calculate volume
    double calculateVolume() {
        return calculateBaseArea() * height;  // Volume = Base Area × Height
    }
    
}

