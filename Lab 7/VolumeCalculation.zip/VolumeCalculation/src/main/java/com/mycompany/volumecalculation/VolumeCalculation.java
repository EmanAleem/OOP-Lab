/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.volumecalculation;

/**
 *
 * @author MARK 1
 */
import java.util.Scanner;

public class VolumeCalculation {

    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);  // Create Scanner object
        System.out.print("Enter the radius of the cylinder: ");
        double radius = scanner.nextDouble();
        System.out.print("Enter the height of the cylinder: ");
        double height = scanner.nextDouble();
        SolidCylinder solid = new SolidCylinder(radius, height);
        solid.displayMessage(); 
        System.out.println("Base Area of Cylinder: " + solid.calculateBaseArea());
        System.out.println("Volume of Solid Cylinder: " + solid.calculateVolume());
        scanner.close();  
    }
    }

