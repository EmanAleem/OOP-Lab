/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.areacalculation;

/**
 *
 * @author MARK 1
 */
public class Shape {
    void displayMessage() {
        System.out.println("This is a shape.");
    }
    
}
